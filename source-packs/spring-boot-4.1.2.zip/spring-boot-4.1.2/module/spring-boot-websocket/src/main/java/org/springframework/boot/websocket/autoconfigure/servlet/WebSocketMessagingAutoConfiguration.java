/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.websocket.autoconfigure.servlet;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.jspecify.annotations.Nullable;
import tools.jackson.databind.json.JsonMapper;

import org.springframework.boot.LazyInitializationExcludeFilter;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.messaging.converter.ByteArrayMessageConverter;
import org.springframework.messaging.converter.DefaultContentTypeResolver;
import org.springframework.messaging.converter.JacksonJsonMessageConverter;
import org.springframework.messaging.converter.MessageConverter;
import org.springframework.messaging.converter.StringMessageConverter;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.socket.config.annotation.DelegatingWebSocketMessageBrokerConfiguration;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * {@link EnableAutoConfiguration Auto-configuration} for WebSocket-based messaging.
 *
 * @author Andy Wilkinson
 * @author Lasse Wulff
 * @author Moritz Halbritter
 * @since 4.0.0
 */
@AutoConfiguration(afterName = { "org.springframework.boot.jackson.autoconfigure.JacksonAutoConfiguration",
		"org.springframework.boot.jackson2.autoconfigure.Jackson2AutoConfiguration" })
@ConditionalOnWebApplication(type = Type.SERVLET)
@ConditionalOnClass({ WebSocketMessageBrokerConfigurer.class, DelegatingWebSocketMessageBrokerConfiguration.class })
@ConditionalOnBean(DelegatingWebSocketMessageBrokerConfiguration.class)
public final class WebSocketMessagingAutoConfiguration {

	@Bean
	static LazyInitializationExcludeFilter eagerStompWebSocketHandlerMapping() {
		return (name, definition, type) -> name.equals("stompWebSocketHandlerMapping");
	}

	@Bean
	SpringBootWebSocketMessageBrokerConfigurer springBootWebSocketMessageBrokerConfigurer(
			Map<String, AsyncTaskExecutor> taskExecutors) {
		return new SpringBootWebSocketMessageBrokerConfigurer(taskExecutors);
	}

	@Order(1)
	@Configuration(proxyBeanMethods = false)
	@ConditionalOnProperty(name = "spring.websocket.messaging.preferred-json-mapper", havingValue = "jackson",
			matchIfMissing = true)
	@ConditionalOnBean(JsonMapper.class)
	@ConditionalOnClass(JsonMapper.class)
	static class JacksonWebSocketMessageConverterConfiguration implements WebSocketMessageBrokerConfigurer {

		private final JsonMapper jsonMapper;

		JacksonWebSocketMessageConverterConfiguration(JsonMapper jsonMapper) {
			this.jsonMapper = jsonMapper;
		}

		@Override
		public boolean configureMessageConverters(List<MessageConverter> messageConverters) {
			JacksonJsonMessageConverter converter = new JacksonJsonMessageConverter(this.jsonMapper);
			DefaultContentTypeResolver resolver = new DefaultContentTypeResolver();
			resolver.setDefaultMimeType(MimeTypeUtils.APPLICATION_JSON);
			converter.setContentTypeResolver(resolver);
			messageConverters.add(converter);
			return false;
		}

	}

	@Order(1)
	@Configuration(proxyBeanMethods = false)
	@Deprecated(since = "4.0.0", forRemoval = true)
	@SuppressWarnings("removal")
	@Conditional(NoJacksonOrJackson2Preferred.class)
	@ConditionalOnBean(ObjectMapper.class)
	@ConditionalOnClass(ObjectMapper.class)
	static class Jackson2WebSocketMessageConverterConfiguration implements WebSocketMessageBrokerConfigurer {

		private final ObjectMapper objectMapper;

		Jackson2WebSocketMessageConverterConfiguration(ObjectMapper objectMapper) {
			this.objectMapper = objectMapper;
		}

		@Override
		public boolean configureMessageConverters(List<MessageConverter> messageConverters) {
			org.springframework.messaging.converter.MappingJackson2MessageConverter converter = new org.springframework.messaging.converter.MappingJackson2MessageConverter(
					this.objectMapper);
			DefaultContentTypeResolver resolver = new DefaultContentTypeResolver();
			resolver.setDefaultMimeType(MimeTypeUtils.APPLICATION_JSON);
			converter.setContentTypeResolver(resolver);
			messageConverters.add(converter);
			return false;
		}

	}

	static class NoJacksonOrJackson2Preferred extends AnyNestedCondition {

		NoJacksonOrJackson2Preferred() {
			super(ConfigurationPhase.PARSE_CONFIGURATION);
		}

		@ConditionalOnMissingClass("tools.jackson.databind.json.JsonMapper")
		static class NoJackson {

		}

		@ConditionalOnProperty(name = "spring.websocket.messaging.preferred-json-mapper", havingValue = "jackson2")
		static class Jackson2Preferred {

		}

	}

	static class SpringBootWebSocketMessageBrokerConfigurer implements WebSocketMessageBrokerConfigurer, Ordered {

		private final @Nullable AsyncTaskExecutor executor;

		SpringBootWebSocketMessageBrokerConfigurer(Map<String, AsyncTaskExecutor> taskExecutors) {
			this.executor = determineAsyncTaskExecutor(taskExecutors);
		}

		private static @Nullable AsyncTaskExecutor determineAsyncTaskExecutor(
				Map<String, AsyncTaskExecutor> taskExecutors) {
			if (taskExecutors.size() == 1) {
				return taskExecutors.values().iterator().next();
			}
			return taskExecutors.get(TaskExecutionAutoConfiguration.APPLICATION_TASK_EXECUTOR_BEAN_NAME);
		}

		@Override
		public boolean configureMessageConverters(List<MessageConverter> messageConverters) {
			messageConverters.add(new StringMessageConverter());
			messageConverters.add(new ByteArrayMessageConverter());
			return false;
		}

		@Override
		public void configureClientInboundChannel(ChannelRegistration registration) {
			if (this.executor != null) {
				registration.executor(this.executor);
			}
		}

		@Override
		public void configureClientOutboundChannel(ChannelRegistration registration) {
			if (this.executor != null) {
				registration.executor(this.executor);
			}
		}

		@Override
		public int getOrder() {
			return 0;
		}

	}

}
