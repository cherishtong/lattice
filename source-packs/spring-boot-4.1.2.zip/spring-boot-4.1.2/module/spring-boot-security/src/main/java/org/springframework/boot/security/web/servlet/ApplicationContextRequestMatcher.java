/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.security.web.servlet;

import java.util.function.Supplier;

import jakarta.servlet.http.HttpServletRequest;
import org.jspecify.annotations.Nullable;

import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.boot.web.server.context.WebServerApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * {@link ApplicationContext} backed {@link RequestMatcher}. Can work directly with the
 * {@link ApplicationContext}, obtain an existing bean or
 * {@link AutowireCapableBeanFactory#createBean(Class) create a new bean} that is
 * autowired in the usual way.
 *
 * @param <C> the type of the context that the match method actually needs to use. Can be
 * an {@link ApplicationContext} or a class of an {@link ApplicationContext#getBean(Class)
 * existing bean}.
 * @author Phillip Webb
 * @since 4.0.0
 */
public abstract class ApplicationContextRequestMatcher<C> implements RequestMatcher {

	private static final String WEB_SERVER_CONTEXT_CLASS = "org.springframework.boot.web.server.context.WebServerApplicationContext";

	private final Class<? extends C> contextClass;

	private volatile boolean initialized;

	private final Object initializeLock = new Object();

	public ApplicationContextRequestMatcher(Class<? extends C> contextClass) {
		Assert.notNull(contextClass, "'contextClass' must not be null");
		this.contextClass = contextClass;
	}

	@Override
	public final boolean matches(HttpServletRequest request) {
		WebApplicationContext webApplicationContext = WebApplicationContextUtils
			.getRequiredWebApplicationContext(request.getServletContext());
		if (ignoreApplicationContext(webApplicationContext)) {
			return false;
		}
		Supplier<C> context = () -> getContext(webApplicationContext);
		if (!this.initialized) {
			synchronized (this.initializeLock) {
				if (!this.initialized) {
					initialized(context);
					this.initialized = true;
				}
			}
		}
		return matches(request, context);
	}

	@SuppressWarnings("unchecked")
	private C getContext(WebApplicationContext webApplicationContext) {
		if (this.contextClass.isInstance(webApplicationContext)) {
			return (C) webApplicationContext;
		}
		return webApplicationContext.getBean(this.contextClass);
	}

	/**
	 * Returns if the {@link WebApplicationContext} should be ignored and not used for
	 * matching. If this method returns {@code true} then the context will not be used and
	 * the {@link #matches(HttpServletRequest) matches} method will return {@code false}.
	 * @param webApplicationContext the candidate web application context
	 * @return if the application context should be ignored
	 */
	protected boolean ignoreApplicationContext(WebApplicationContext webApplicationContext) {
		return false;
	}

	/**
	 * Method that can be implemented by subclasses that wish to initialize items the
	 * first time that the matcher is called. This method will be called only once and
	 * only if {@link #ignoreApplicationContext(WebApplicationContext)} returns
	 * {@code false}. Note that the supplied context will be based on the
	 * <strong>first</strong> request sent to the matcher.
	 * @param context a supplier for the initialized context (may throw an exception)
	 * @see #ignoreApplicationContext(WebApplicationContext)
	 */
	protected void initialized(Supplier<C> context) {
	}

	/**
	 * Decides whether the rule implemented by the strategy matches the supplied request.
	 * @param request the source request
	 * @param context a supplier for the initialized context (may throw an exception)
	 * @return if the request matches
	 */
	protected abstract boolean matches(HttpServletRequest request, Supplier<C> context);

	/**
	 * Returns {@code true} if the specified context is a
	 * {@link WebServerApplicationContext} with a matching server namespace.
	 * @param context the context to check
	 * @param serverNamespace the server namespace to match against
	 * @return {@code true} if the server namespace of the context matches
	 * @since 4.0.1
	 */
	protected final boolean hasServerNamespace(@Nullable ApplicationContext context, String serverNamespace) {
		if (!ClassUtils.isPresent(WEB_SERVER_CONTEXT_CLASS, null)) {
			return false;
		}
		return WebServerApplicationContext.hasServerNamespace(context, serverNamespace);
	}

	/**
	 * Returns the server namespace if the specified context is a
	 * {@link WebServerApplicationContext}.
	 * @param context the context
	 * @return the server namespace or {@code null} if the context is not a
	 * {@link WebServerApplicationContext}
	 * @since 4.0.1
	 */
	protected final @Nullable String getServerNamespace(@Nullable ApplicationContext context) {
		if (!ClassUtils.isPresent(WEB_SERVER_CONTEXT_CLASS, null)) {
			return null;
		}
		return WebServerApplicationContext.getServerNamespace(context);
	}

}
