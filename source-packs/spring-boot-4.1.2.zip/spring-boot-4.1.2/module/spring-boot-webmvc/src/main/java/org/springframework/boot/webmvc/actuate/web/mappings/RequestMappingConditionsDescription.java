/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.webmvc.actuate.web.mappings;

import java.util.List;
import java.util.Set;

import org.jspecify.annotations.Nullable;

import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.condition.MediaTypeExpression;
import org.springframework.web.servlet.mvc.condition.NameValueExpression;
import org.springframework.web.servlet.mvc.condition.PathPatternsRequestCondition;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;

/**
 * Description of the conditions of a {@link RequestMappingInfo}.
 *
 * @author Andy Wilkinson
 * @since 4.0.0
 */
public class RequestMappingConditionsDescription {

	private final List<MediaTypeExpressionDescription> consumes;

	private final List<NameValueExpressionDescription> headers;

	private final Set<RequestMethod> methods;

	private final List<NameValueExpressionDescription> params;

	private final Set<String> patterns;

	private final List<MediaTypeExpressionDescription> produces;

	RequestMappingConditionsDescription(RequestMappingInfo requestMapping) {
		this.consumes = requestMapping.getConsumesCondition()
			.getExpressions()
			.stream()
			.map(MediaTypeExpressionDescription::new)
			.toList();
		this.headers = requestMapping.getHeadersCondition()
			.getExpressions()
			.stream()
			.map(NameValueExpressionDescription::new)
			.toList();
		this.methods = requestMapping.getMethodsCondition().getMethods();
		this.params = requestMapping.getParamsCondition()
			.getExpressions()
			.stream()
			.map(NameValueExpressionDescription::new)
			.toList();
		this.patterns = extractPathPatterns(requestMapping);
		this.produces = requestMapping.getProducesCondition()
			.getExpressions()
			.stream()
			.map(MediaTypeExpressionDescription::new)
			.toList();
	}

	@SuppressWarnings({ "removal", "deprecation" })
	private Set<String> extractPathPatterns(RequestMappingInfo requestMapping) {
		org.springframework.web.servlet.mvc.condition.PatternsRequestCondition patternsCondition = requestMapping
			.getPatternsCondition();
		if (patternsCondition != null) {
			return patternsCondition.getPatterns();
		}
		PathPatternsRequestCondition condition = requestMapping.getPathPatternsCondition();
		Assert.state(condition != null, "'condition' must not be null");
		return condition.getPatternValues();
	}

	public List<MediaTypeExpressionDescription> getConsumes() {
		return this.consumes;
	}

	public List<NameValueExpressionDescription> getHeaders() {
		return this.headers;
	}

	public Set<RequestMethod> getMethods() {
		return this.methods;
	}

	public List<NameValueExpressionDescription> getParams() {
		return this.params;
	}

	public Set<String> getPatterns() {
		return this.patterns;
	}

	public List<MediaTypeExpressionDescription> getProduces() {
		return this.produces;
	}

	/**
	 * A description of a {@link MediaTypeExpression} in a request mapping condition.
	 */
	public static class MediaTypeExpressionDescription {

		private final String mediaType;

		private final boolean negated;

		MediaTypeExpressionDescription(MediaTypeExpression expression) {
			this.mediaType = expression.getMediaType().toString();
			this.negated = expression.isNegated();
		}

		public String getMediaType() {
			return this.mediaType;
		}

		public boolean isNegated() {
			return this.negated;
		}

	}

	/**
	 * A description of a {@link NameValueExpression} in a request mapping condition.
	 */
	public static class NameValueExpressionDescription {

		private final String name;

		private final @Nullable Object value;

		private final boolean negated;

		NameValueExpressionDescription(NameValueExpression<?> expression) {
			this.name = expression.getName();
			this.value = expression.getValue();
			this.negated = expression.isNegated();
		}

		public String getName() {
			return this.name;
		}

		public @Nullable Object getValue() {
			return this.value;
		}

		public boolean isNegated() {
			return this.negated;
		}

	}

}
