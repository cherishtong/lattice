/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.webmvc.autoconfigure.actuate.web;

import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.error.ErrorAttributeOptions.Include;
import org.springframework.boot.webmvc.error.ErrorAttributes;
import org.springframework.boot.webmvc.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * {@link Controller @Controller} for handling "/error" path when the management servlet
 * is in a child context. The regular {@link ErrorController} should be available there
 * but because of the way the handler mappings are set up it will not be detected.
 *
 * @author Dave Syer
 * @author Scott Frederick
 * @author Moritz Halbritter
 * @since 4.0.0
 */
@Controller
public class ManagementErrorEndpoint {

	private final ErrorAttributes errorAttributes;

	private final ErrorProperties errorProperties;

	public ManagementErrorEndpoint(ErrorAttributes errorAttributes, ErrorProperties errorProperties) {
		Assert.notNull(errorAttributes, "'errorAttributes' must not be null");
		Assert.notNull(errorProperties, "'errorProperties' must not be null");
		this.errorAttributes = errorAttributes;
		this.errorProperties = errorProperties;
	}

	@RequestMapping("${spring.web.error.path:${error.path:/error}}")
	@ResponseBody
	public Map<String, @Nullable Object> invoke(ServletWebRequest request) {
		return this.errorAttributes.getErrorAttributes(request, getErrorAttributeOptions(request));
	}

	private ErrorAttributeOptions getErrorAttributeOptions(ServletWebRequest request) {
		ErrorAttributeOptions options = ErrorAttributeOptions.defaults();
		if (this.errorProperties.isIncludeException()) {
			options = options.including(Include.EXCEPTION);
		}
		if (includeStackTrace(request)) {
			options = options.including(Include.STACK_TRACE);
		}
		if (includeMessage(request)) {
			options = options.including(Include.MESSAGE);
		}
		if (includeBindingErrors(request)) {
			options = options.including(Include.BINDING_ERRORS);
		}
		options = includePath(request) ? options.including(Include.PATH) : options.excluding(Include.PATH);
		return options;
	}

	private boolean includeStackTrace(ServletWebRequest request) {
		return switch (this.errorProperties.getIncludeStacktrace()) {
			case ALWAYS -> true;
			case ON_PARAM -> getBooleanParameter(request, "trace");
			case NEVER -> false;
		};
	}

	private boolean includeMessage(ServletWebRequest request) {
		return switch (this.errorProperties.getIncludeMessage()) {
			case ALWAYS -> true;
			case ON_PARAM -> getBooleanParameter(request, "message");
			case NEVER -> false;
		};
	}

	private boolean includeBindingErrors(ServletWebRequest request) {
		return switch (this.errorProperties.getIncludeBindingErrors()) {
			case ALWAYS -> true;
			case ON_PARAM -> getBooleanParameter(request, "errors");
			case NEVER -> false;
		};
	}

	private boolean includePath(ServletWebRequest request) {
		return switch (this.errorProperties.getIncludePath()) {
			case ALWAYS -> true;
			case ON_PARAM -> getBooleanParameter(request, "path");
			case NEVER -> false;
		};
	}

	protected boolean getBooleanParameter(ServletWebRequest request, String parameterName) {
		String parameter = request.getParameter(parameterName);
		if (parameter == null) {
			return false;
		}
		return !"false".equalsIgnoreCase(parameter);
	}

}
