/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.sql.init;

import java.nio.charset.Charset;
import java.util.List;

import org.jspecify.annotations.Nullable;

/**
 * Settings for initializing an SQL database.
 *
 * @author Andy Wilkinson
 * @since 2.5.0
 */
public class DatabaseInitializationSettings {

	private @Nullable List<String> schemaLocations;

	private @Nullable List<String> dataLocations;

	private boolean continueOnError;

	private String separator = ";";

	private @Nullable Charset encoding;

	private DatabaseInitializationMode mode = DatabaseInitializationMode.EMBEDDED;

	/**
	 * Returns the locations of the schema (DDL) scripts to apply to the database.
	 * @return the locations of the schema scripts
	 */
	public @Nullable List<String> getSchemaLocations() {
		return this.schemaLocations;
	}

	/**
	 * Sets the locations of schema (DDL) scripts to apply to the database. By default,
	 * initialization will fail if a location does not exist. To prevent a failure, a
	 * location can be made optional by prefixing it with {@code optional:}.
	 * @param schemaLocations locations of the schema scripts
	 */
	public void setSchemaLocations(@Nullable List<String> schemaLocations) {
		this.schemaLocations = schemaLocations;
	}

	/**
	 * Returns the locations of data (DML) scripts to apply to the database.
	 * @return the locations of the data scripts
	 */
	public @Nullable List<String> getDataLocations() {
		return this.dataLocations;
	}

	/**
	 * Sets the locations of data (DML) scripts to apply to the database. By default,
	 * initialization will fail if a location does not exist. To prevent a failure, a
	 * location can be made optional by prefixing it with {@code optional:}.
	 * @param dataLocations locations of the data scripts
	 */
	public void setDataLocations(@Nullable List<String> dataLocations) {
		this.dataLocations = dataLocations;
	}

	/**
	 * Returns whether to continue when an error occurs while applying a schema or data
	 * script.
	 * @return whether to continue on error
	 */
	public boolean isContinueOnError() {
		return this.continueOnError;
	}

	/**
	 * Sets whether initialization should continue when an error occurs when applying a
	 * schema or data script.
	 * @param continueOnError whether to continue when an error occurs.
	 */
	public void setContinueOnError(boolean continueOnError) {
		this.continueOnError = continueOnError;
	}

	/**
	 * Returns the statement separator used in the schema and data scripts.
	 * @return the statement separator
	 */
	public String getSeparator() {
		return this.separator;
	}

	/**
	 * Sets the statement separator to use when reading the schema and data scripts.
	 * @param separator statement separator used in the schema and data scripts
	 */
	public void setSeparator(String separator) {
		this.separator = separator;
	}

	/**
	 * Returns the encoding to use when reading the schema and data scripts.
	 * @return the script encoding
	 */
	public @Nullable Charset getEncoding() {
		return this.encoding;
	}

	/**
	 * Sets the encoding to use when reading the schema and data scripts.
	 * @param encoding encoding to use when reading the schema and data scripts
	 */
	public void setEncoding(@Nullable Charset encoding) {
		this.encoding = encoding;
	}

	/**
	 * Gets the mode to use when determining whether database initialization should be
	 * performed.
	 * @return the initialization mode
	 * @since 2.5.1
	 */
	public DatabaseInitializationMode getMode() {
		return this.mode;
	}

	/**
	 * Sets the mode the use when determining whether database initialization should be
	 * performed.
	 * @param mode the initialization mode
	 * @since 2.5.1
	 */
	public void setMode(DatabaseInitializationMode mode) {
		this.mode = mode;
	}

}
