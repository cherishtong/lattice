/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.sql.autoconfigure.init;

import java.util.Locale;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.autoconfigure.condition.ConditionMessage;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.boot.sql.init.DatabaseInitializationMode;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.util.StringUtils;

/**
 * Condition that checks if the database initialization of a particular component should
 * be considered.
 *
 * @author Stephane Nicoll
 * @since 4.0.0
 * @see DatabaseInitializationMode
 */
public abstract class OnDatabaseInitializationCondition extends SpringBootCondition {

	private final String name;

	private final String[] propertyNames;

	/**
	 * Create a new instance with the name of the component and the property names to
	 * check, in order. If a property is set, its value is used to determine the outcome
	 * and remaining properties are not tested.
	 * @param name the name of the component
	 * @param propertyNames the properties to check (in order)
	 */
	protected OnDatabaseInitializationCondition(String name, String... propertyNames) {
		this.name = name;
		this.propertyNames = propertyNames;
	}

	@Override
	public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
		Environment environment = context.getEnvironment();
		String propertyName = getConfiguredProperty(environment);
		DatabaseInitializationMode mode = getDatabaseInitializationMode(environment, propertyName);
		boolean match = match(mode);
		String messagePrefix = (propertyName != null) ? propertyName : "default value";
		return new ConditionOutcome(match, ConditionMessage.forCondition(this.name + "Database Initialization")
			.because(messagePrefix + " is " + mode));
	}

	private boolean match(DatabaseInitializationMode mode) {
		return !mode.equals(DatabaseInitializationMode.NEVER);
	}

	private DatabaseInitializationMode getDatabaseInitializationMode(Environment environment,
			@Nullable String propertyName) {
		if (StringUtils.hasText(propertyName)) {
			String candidate = environment.getProperty(propertyName, "embedded").toUpperCase(Locale.ENGLISH);
			if (StringUtils.hasText(candidate)) {
				return DatabaseInitializationMode.valueOf(candidate);
			}
		}
		return DatabaseInitializationMode.EMBEDDED;
	}

	private @Nullable String getConfiguredProperty(Environment environment) {
		for (String propertyName : this.propertyNames) {
			if (environment.containsProperty(propertyName)) {
				return propertyName;
			}
		}
		return null;
	}

}
