/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.session.actuate.endpoint;

import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.session.actuate.endpoint.SessionsDescriptor.SessionDescriptor;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.SessionRepository;
import org.springframework.util.Assert;

/**
 * {@link Endpoint @Endpoint} to expose information about HTTP {@link Session}s on a
 * Servlet stack.
 *
 * @author Vedran Pavic
 * @since 4.0.0
 */
@Endpoint(id = "sessions")
public class SessionsEndpoint {

	private final SessionRepository<? extends Session> sessionRepository;

	private final @Nullable FindByIndexNameSessionRepository<? extends Session> indexedSessionRepository;

	/**
	 * Create a new {@link SessionsEndpoint} instance.
	 * @param sessionRepository the session repository
	 * @param indexedSessionRepository the indexed session repository
	 */
	public SessionsEndpoint(SessionRepository<? extends Session> sessionRepository,
			@Nullable FindByIndexNameSessionRepository<? extends Session> indexedSessionRepository) {
		Assert.notNull(sessionRepository, "'sessionRepository' must not be null");
		this.sessionRepository = sessionRepository;
		this.indexedSessionRepository = indexedSessionRepository;
	}

	@ReadOperation
	public @Nullable SessionsDescriptor sessionsForUsername(String username) {
		if (this.indexedSessionRepository == null) {
			return null;
		}
		Map<String, ? extends Session> sessions = this.indexedSessionRepository.findByPrincipalName(username);
		return new SessionsDescriptor(sessions);
	}

	@ReadOperation
	public @Nullable SessionDescriptor getSession(@Selector String sessionId) {
		Session session = this.sessionRepository.findById(sessionId);
		if (session == null) {
			return null;
		}
		return new SessionDescriptor(session);
	}

	@DeleteOperation
	public void deleteSession(@Selector String sessionId) {
		this.sessionRepository.deleteById(sessionId);
	}

}
