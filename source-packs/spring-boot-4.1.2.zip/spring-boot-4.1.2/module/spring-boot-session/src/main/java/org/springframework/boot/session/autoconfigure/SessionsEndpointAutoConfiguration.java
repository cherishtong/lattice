/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.session.autoconfigure;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.actuate.autoconfigure.endpoint.condition.ConditionalOnAvailableEndpoint;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
import org.springframework.boot.session.actuate.endpoint.ReactiveSessionsEndpoint;
import org.springframework.boot.session.actuate.endpoint.SessionsEndpoint;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.ReactiveFindByIndexNameSessionRepository;
import org.springframework.session.ReactiveSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.SessionRepository;

/**
 * {@link EnableAutoConfiguration Auto-configuration} for {@link SessionsEndpoint}.
 *
 * @author Vedran Pavic
 * @since 4.0.0
 */
@AutoConfiguration(after = SessionAutoConfiguration.class)
@ConditionalOnClass({ Session.class, SessionsEndpoint.class, ConditionalOnAvailableEndpoint.class })
@ConditionalOnAvailableEndpoint(SessionsEndpoint.class)
public final class SessionsEndpointAutoConfiguration {

	@Configuration(proxyBeanMethods = false)
	@ConditionalOnWebApplication(type = Type.SERVLET)
	@ConditionalOnBean(SessionRepository.class)
	static class ServletSessionEndpointConfiguration {

		@Bean
		@ConditionalOnMissingBean
		SessionsEndpoint sessionEndpoint(SessionRepository<?> sessionRepository,
				ObjectProvider<FindByIndexNameSessionRepository<?>> indexedSessionRepository) {
			return new SessionsEndpoint(sessionRepository, indexedSessionRepository.getIfAvailable());
		}

	}

	@Configuration(proxyBeanMethods = false)
	@ConditionalOnWebApplication(type = Type.REACTIVE)
	@ConditionalOnBean(ReactiveSessionRepository.class)
	static class ReactiveSessionEndpointConfiguration {

		@Bean
		@ConditionalOnMissingBean
		ReactiveSessionsEndpoint sessionsEndpoint(ReactiveSessionRepository<?> sessionRepository,
				ObjectProvider<ReactiveFindByIndexNameSessionRepository<?>> indexedSessionRepository) {
			return new ReactiveSessionsEndpoint(sessionRepository, indexedSessionRepository.getIfAvailable());
		}

	}

}
