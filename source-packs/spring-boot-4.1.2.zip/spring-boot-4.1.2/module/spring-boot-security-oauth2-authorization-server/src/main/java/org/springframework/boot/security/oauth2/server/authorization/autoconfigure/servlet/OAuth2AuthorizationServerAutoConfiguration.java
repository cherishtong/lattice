/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.security.oauth2.server.authorization.autoconfigure.servlet;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
import org.springframework.boot.security.autoconfigure.SecurityAutoConfiguration;
import org.springframework.boot.security.autoconfigure.UserDetailsServiceAutoConfiguration;
import org.springframework.boot.security.autoconfigure.actuate.web.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.security.oauth2.server.authorization.OAuth2Authorization;

/**
 * {@link EnableAutoConfiguration Auto-configuration} for OAuth2 authorization server
 * support.
 *
 * <p>
 * <strong>Note:</strong> This configuration and
 * {@link OAuth2AuthorizationServerJwtAutoConfiguration} work together to ensure that the
 * {@link org.springframework.security.config.ObjectPostProcessor} is defined
 * <strong>BEFORE</strong> {@link UserDetailsServiceAutoConfiguration} so that a
 * {@link org.springframework.security.core.userdetails.UserDetailsService} can be created
 * if necessary.
 *
 * @author Steve Riesenberg
 * @since 4.0.0
 * @see OAuth2AuthorizationServerJwtAutoConfiguration
 */
@AutoConfiguration(before = { SecurityAutoConfiguration.class, ManagementWebSecurityAutoConfiguration.class },
		beforeName = "org.springframework.boot.security.oauth2.server.resource.autoconfigure.OAuth2ResourceServerAutoConfiguration")
@ConditionalOnClass(OAuth2Authorization.class)
@ConditionalOnWebApplication(type = Type.SERVLET)
@Import({ OAuth2AuthorizationServerConfiguration.class, OAuth2AuthorizationServerWebSecurityConfiguration.class })
public final class OAuth2AuthorizationServerAutoConfiguration {

}
