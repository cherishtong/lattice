/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.security.oauth2.server.resource.autoconfigure;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector;
import org.springframework.security.oauth2.server.resource.introspection.SpringOpaqueTokenIntrospector;
import org.springframework.util.Assert;

/**
 * Configures an {@link OpaqueTokenIntrospector} when a token introspection endpoint is
 * available.
 *
 * @author Madhura Bhave
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnMissingBean(OpaqueTokenIntrospector.class)
class OpaqueTokenIntrospectionConfiguration {

	@Bean
	@ConditionalOnProperty(name = "spring.security.oauth2.resourceserver.opaquetoken.introspection-uri")
	SpringOpaqueTokenIntrospector opaqueTokenIntrospector(OAuth2ResourceServerProperties properties,
			ObjectProvider<SpringOpaqueTokenIntrospectorBuilderCustomizer> customizers) {
		OAuth2ResourceServerProperties.Opaquetoken token = properties.getOpaquetoken();
		String introspectionUri = token.getIntrospectionUri();
		Assert.state(introspectionUri != null,
				"No 'spring.security.oauth2.resourceserver.opaquetoken.introspection-uri' property specified");
		Assert.state(token.getClientId() != null,
				"No 'spring.security.oauth2.resourceserver.opaquetoken.client-id' property specified");
		Assert.state(token.getClientSecret() != null,
				"No 'spring.security.oauth2.resourceserver.opaquetoken.client-secret' property specified");
		SpringOpaqueTokenIntrospector.Builder builder = SpringOpaqueTokenIntrospector
			.withIntrospectionUri(introspectionUri)
			.clientId(token.getClientId())
			.clientSecret(token.getClientSecret());
		customizers.orderedStream().forEach((customizer) -> customizer.customize(builder));
		return builder.build();
	}

}
