/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.security.oauth2.server.resource.autoconfigure.reactive;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
import org.springframework.boot.autoconfigure.condition.ConditionMessage;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.OnPropertyListCondition;
import org.springframework.boot.context.properties.PropertyMapper;
import org.springframework.boot.context.properties.source.MutuallyExclusiveConfigurationPropertiesException;
import org.springframework.boot.security.oauth2.server.resource.autoconfigure.OAuth2ResourceServerProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.DelegatingJwtGrantedAuthoritiesConverter;
import org.springframework.security.oauth2.server.resource.authentication.ExpressionJwtGrantedAuthoritiesConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.oauth2.server.resource.authentication.ReactiveJwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.ReactiveJwtGrantedAuthoritiesConverterAdapter;
import org.springframework.util.CollectionUtils;

/**
 * {@link Configuration @Configuration} for JWT converter beans.
 *
 * @author Madhura Bhave
 * @author Artsiom Yudovin
 * @author HaiTao Zhang
 * @author Anastasiia Losieva
 * @author Mushtaq Ahmed
 * @author Roman Golovin
 * @author Yan Kardziyaka
 * @author Phillip Webb
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(ReactiveJwtDecoder.class)
@ConditionalOnMissingBean(ReactiveJwtAuthenticationConverter.class)
@Conditional(ReactiveJwtConverterConfiguration.PropertiesCondition.class)
class ReactiveJwtConverterConfiguration {

	@Bean
	ReactiveJwtAuthenticationConverter reactiveJwtAuthenticationConverter(OAuth2ResourceServerProperties properties) {
		PropertyMapper map = PropertyMapper.get();
		OAuth2ResourceServerProperties.Jwt jwtProperties = properties.getJwt();
		ReactiveJwtAuthenticationConverter jwtAuthenticationConverter = new ReactiveJwtAuthenticationConverter();
		map.from(jwtProperties::getPrincipalClaimName).to(jwtAuthenticationConverter::setPrincipalClaimName);
		map.from(jwtProperties)
			.as(this::grantedAuthoritiesConverter)
			.as(ReactiveJwtGrantedAuthoritiesConverterAdapter::new)
			.to(jwtAuthenticationConverter::setJwtGrantedAuthoritiesConverter);
		return jwtAuthenticationConverter;
	}

	private Converter<Jwt, Collection<GrantedAuthority>> grantedAuthoritiesConverter(
			OAuth2ResourceServerProperties.Jwt properties) {
		List<String> authoritiesClaimExpressions = properties.getAuthoritiesClaimExpressions();
		if (CollectionUtils.isEmpty(authoritiesClaimExpressions)) {
			return createJwtGrantedAuthoritiesConverter(properties);
		}
		return createExpressionJwtGrantedAuthoritiesConverters(properties, authoritiesClaimExpressions);
	}

	private Converter<Jwt, Collection<GrantedAuthority>> createJwtGrantedAuthoritiesConverter(
			OAuth2ResourceServerProperties.Jwt properties) {
		PropertyMapper map = PropertyMapper.get();
		JwtGrantedAuthoritiesConverter converter = new JwtGrantedAuthoritiesConverter();
		map.from(properties::getAuthorityPrefix).to(converter::setAuthorityPrefix);
		map.from(properties::getAuthoritiesClaimDelimiter).to(converter::setAuthoritiesClaimDelimiter);
		map.from(properties::getAuthoritiesClaimName).to(converter::setAuthoritiesClaimName);
		return converter;
	}

	private Converter<Jwt, Collection<GrantedAuthority>> createExpressionJwtGrantedAuthoritiesConverters(
			OAuth2ResourceServerProperties.Jwt properties, List<String> claimExpressions) {
		checkMutualExclusivity(properties);
		List<Converter<Jwt, Collection<GrantedAuthority>>> converters = new ArrayList<>();
		SpelExpressionParser parser = new SpelExpressionParser();
		for (String claimExpression : claimExpressions) {
			ExpressionJwtGrantedAuthoritiesConverter converter = new ExpressionJwtGrantedAuthoritiesConverter(
					parser.parseExpression(claimExpression));
			if (properties.getAuthorityPrefix() != null) {
				converter.setAuthorityPrefix(properties.getAuthorityPrefix());
			}
			converters.add(converter);
		}
		return (converters.size() == 1) ? converters.get(0) : new DelegatingJwtGrantedAuthoritiesConverter(converters);
	}

	private void checkMutualExclusivity(OAuth2ResourceServerProperties.Jwt properties) {
		MutuallyExclusiveConfigurationPropertiesException.throwIfMultipleMatchingValuesIn((entries) -> {
			entries.put("spring.security.oauth2.resourceserver.jwt.authorities-claim-expressions",
					properties.getAuthoritiesClaimExpressions());
			entries.put("spring.security.oauth2.resourceserver.jwt.authorities-claim-name",
					properties.getAuthoritiesClaimName());
		}, (value) -> !nullOrEmptyList(value));
		MutuallyExclusiveConfigurationPropertiesException.throwIfMultipleMatchingValuesIn((entries) -> {
			entries.put("spring.security.oauth2.resourceserver.jwt.authorities-claim-expressions",
					properties.getAuthoritiesClaimExpressions());
			entries.put("spring.security.oauth2.resourceserver.jwt.authorities-claim-delimiter",
					properties.getAuthoritiesClaimDelimiter());
		}, (value) -> !nullOrEmptyList(value));
	}

	private boolean nullOrEmptyList(Object value) {
		if (value == null) {
			return true;
		}
		return (value instanceof List<?> list) ? list.isEmpty() : false;
	}

	static class PropertiesCondition extends AnyNestedCondition {

		PropertiesCondition() {
			super(ConfigurationPhase.REGISTER_BEAN);
		}

		@ConditionalOnProperty("spring.security.oauth2.resourceserver.jwt.authority-prefix")
		static class OnAuthorityPrefix {

		}

		@ConditionalOnProperty("spring.security.oauth2.resourceserver.jwt.principal-claim-name")
		static class OnPrincipalClaimName {

		}

		@ConditionalOnProperty("spring.security.oauth2.resourceserver.jwt.authorities-claim-name")
		static class OnAuthoritiesClaimName {

		}

		@ConditionalOnProperty("spring.security.oauth2.resourceserver.jwt.authorities-claim-delimiter")
		static class OnAuthoritiesClaimDelimiter {

		}

		@Conditional(OnAuthoritiesExpressionsCondition.class)
		static class OnAuthoritiesExpressions {

		}

		static class OnAuthoritiesExpressionsCondition extends OnPropertyListCondition {

			OnAuthoritiesExpressionsCondition() {
				super("spring.security.oauth2.resourceserver.jwt.authorities-claim-expressions",
						() -> ConditionMessage.forCondition("Authorities claim expressions"));
			}

		}

	}

}
