/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.security.oauth2.server.resource.autoconfigure;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
import org.springframework.core.io.Resource;
import org.springframework.util.StreamUtils;

/**
 * OAuth 2.0 resource server properties.
 *
 * @author Madhura Bhave
 * @author Artsiom Yudovin
 * @author Mushtaq Ahmed
 * @author Yan Kardziyaka
 * @author Yanming Zhou
 * @since 4.0.0
 */
@ConfigurationProperties("spring.security.oauth2.resourceserver")
public class OAuth2ResourceServerProperties {

	private final Jwt jwt = new Jwt();

	public Jwt getJwt() {
		return this.jwt;
	}

	private final Opaquetoken opaquetoken = new Opaquetoken();

	public Opaquetoken getOpaquetoken() {
		return this.opaquetoken;
	}

	public static class Jwt {

		/**
		 * JSON Web Key URI to use to verify the JWT token.
		 */
		private @Nullable String jwkSetUri;

		/**
		 * JSON Web Algorithms used for verifying the digital signatures.
		 */
		private List<String> jwsAlgorithms = Arrays.asList("RS256");

		/**
		 * URI that can either be an OpenID Connect discovery endpoint or an OAuth 2.0
		 * Authorization Server Metadata endpoint defined by RFC 8414.
		 */
		private @Nullable String issuerUri;

		/**
		 * Location of the file containing the public key used to verify a JWT.
		 */
		private @Nullable Resource publicKeyLocation;

		/**
		 * Identifies the recipients that the JWT is intended for.
		 */
		private List<String> audiences = new ArrayList<>();

		/**
		 * Prefix to use for authorities mapped from JWT.
		 */
		private @Nullable String authorityPrefix;

		/**
		 * Regex to use for splitting the value of the authorities claim into authorities.
		 */
		private @Nullable String authoritiesClaimDelimiter;

		/**
		 * Name of token claim to use for mapping authorities from JWT.
		 */
		private @Nullable String authoritiesClaimName;

		/**
		 * List of expressions to use to extract authorities from a JWT. Mutually
		 * exclusive with
		 * 'spring.security.oauth2.resourceserver.jwt.authorities-claim-name' and
		 * 'spring.security.oauth2.resourceserver.jwt.authorities-claim-delimiter'.
		 */
		private List<String> authoritiesClaimExpressions = new ArrayList<>();

		/**
		 * JWT principal claim name.
		 */
		private @Nullable String principalClaimName;

		public @Nullable String getJwkSetUri() {
			return this.jwkSetUri;
		}

		public void setJwkSetUri(@Nullable String jwkSetUri) {
			this.jwkSetUri = jwkSetUri;
		}

		public List<String> getJwsAlgorithms() {
			return this.jwsAlgorithms;
		}

		public void setJwsAlgorithms(List<String> jwsAlgorithms) {
			this.jwsAlgorithms = jwsAlgorithms;
		}

		public @Nullable String getIssuerUri() {
			return this.issuerUri;
		}

		public void setIssuerUri(@Nullable String issuerUri) {
			this.issuerUri = issuerUri;
		}

		public @Nullable Resource getPublicKeyLocation() {
			return this.publicKeyLocation;
		}

		public void setPublicKeyLocation(@Nullable Resource publicKeyLocation) {
			this.publicKeyLocation = publicKeyLocation;
		}

		public List<String> getAudiences() {
			return this.audiences;
		}

		public void setAudiences(List<String> audiences) {
			this.audiences = audiences;
		}

		public @Nullable String getAuthorityPrefix() {
			return this.authorityPrefix;
		}

		public void setAuthorityPrefix(@Nullable String authorityPrefix) {
			this.authorityPrefix = authorityPrefix;
		}

		public @Nullable String getAuthoritiesClaimDelimiter() {
			return this.authoritiesClaimDelimiter;
		}

		public void setAuthoritiesClaimDelimiter(@Nullable String authoritiesClaimDelimiter) {
			this.authoritiesClaimDelimiter = authoritiesClaimDelimiter;
		}

		public @Nullable String getAuthoritiesClaimName() {
			return this.authoritiesClaimName;
		}

		public void setAuthoritiesClaimName(@Nullable String authoritiesClaimName) {
			this.authoritiesClaimName = authoritiesClaimName;
		}

		public List<String> getAuthoritiesClaimExpressions() {
			return this.authoritiesClaimExpressions;
		}

		public void setAuthoritiesClaimExpressions(List<String> authoritiesClaimExpressions) {
			this.authoritiesClaimExpressions = authoritiesClaimExpressions;
		}

		public @Nullable String getPrincipalClaimName() {
			return this.principalClaimName;
		}

		public void setPrincipalClaimName(@Nullable String principalClaimName) {
			this.principalClaimName = principalClaimName;
		}

		public String readPublicKey() throws IOException {
			String key = "spring.security.oauth2.resourceserver.jwt.public-key-location";
			if (this.publicKeyLocation == null) {
				throw new InvalidConfigurationPropertyValueException(key, this.publicKeyLocation,
						"No public key location specified");
			}
			if (!this.publicKeyLocation.exists()) {
				throw new InvalidConfigurationPropertyValueException(key, this.publicKeyLocation,
						"Public key location does not exist");
			}
			try (InputStream inputStream = this.publicKeyLocation.getInputStream()) {
				return StreamUtils.copyToString(inputStream, StandardCharsets.UTF_8);
			}
		}

	}

	public static class Opaquetoken {

		/**
		 * Client id used to authenticate with the token introspection endpoint.
		 */
		private @Nullable String clientId;

		/**
		 * Client secret used to authenticate with the token introspection endpoint.
		 */
		private @Nullable String clientSecret;

		/**
		 * OAuth 2.0 endpoint through which token introspection is accomplished.
		 */
		private @Nullable String introspectionUri;

		public @Nullable String getClientId() {
			return this.clientId;
		}

		public void setClientId(@Nullable String clientId) {
			this.clientId = clientId;
		}

		public @Nullable String getClientSecret() {
			return this.clientSecret;
		}

		public void setClientSecret(@Nullable String clientSecret) {
			this.clientSecret = clientSecret;
		}

		public @Nullable String getIntrospectionUri() {
			return this.introspectionUri;
		}

		public void setIntrospectionUri(@Nullable String introspectionUri) {
			this.introspectionUri = introspectionUri;
		}

	}

}
