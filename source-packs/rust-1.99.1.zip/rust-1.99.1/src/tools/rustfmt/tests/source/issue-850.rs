const unsafe fn x() {}
