macro_rules! statement {
    () => {;};
}
