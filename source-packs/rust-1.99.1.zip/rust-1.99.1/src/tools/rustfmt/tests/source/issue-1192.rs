fn main() {
    assert!(true)   ;
}
