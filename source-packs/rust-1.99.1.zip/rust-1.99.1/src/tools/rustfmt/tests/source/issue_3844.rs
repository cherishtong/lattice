fn main() {
|| {{}};
}
