fn foo(  /* comment */
) {}
