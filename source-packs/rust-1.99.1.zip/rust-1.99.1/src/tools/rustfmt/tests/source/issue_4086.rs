#[cfg(any())]
extern  "C++"     {}
