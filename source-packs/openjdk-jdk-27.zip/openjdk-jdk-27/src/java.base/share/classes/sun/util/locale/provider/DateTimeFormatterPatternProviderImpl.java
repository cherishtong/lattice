/*
 * Copyright (c) 2016, 2026, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
package sun.util.locale.provider;

import java.time.DateTimeException;
import java.time.format.DateTimeFormatterPatternProvider;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Concrete implementation of the {@link java.time.format.DateTimeFormatterPatternProvider
 * } class
 *
 */
public class DateTimeFormatterPatternProviderImpl extends DateTimeFormatterPatternProvider implements AvailableLanguageTags {

    private final LocaleProviderAdapter.Type type;
    private final Set<String> langtags;

    public DateTimeFormatterPatternProviderImpl(LocaleProviderAdapter.Type type, Set<String> langtags) {
        this.type = type;
        this.langtags = langtags;
    }

    /**
     * {@return an array of all locales for which this locale service provider
     * can provide localized objects or names}
     */
    @Override
    public Locale[] getAvailableLocales() {
        return LocaleProviderAdapter.toLocaleArray(langtags);
    }

    @Override
    public boolean isSupportedLocale(Locale locale) {
        return LocaleProviderAdapter.forType(type).isSupportedProviderLocale(locale, langtags);
    }

    @Override
    public String getDateTimeFormatterPattern(FormatStyle dateStyle, FormatStyle timeStyle, String calType, Locale locale) {
        Objects.requireNonNull(calType);
        Objects.requireNonNull(locale);
        if (dateStyle == null && timeStyle == null) {
            throw new IllegalArgumentException("Both \"dateStyle\" and \"timeStyle\" are null.");
        }
        LocaleResources lr = LocaleProviderAdapter.getResourceBundleBased().getLocaleResources(locale);
        return lr.getDateTimeFormatterPattern(dateStyle, timeStyle, calType);
    }

    @Override
    public String getDateTimeFormatterPattern(String requestedTemplate, String calType, Locale locale) {
        Objects.requireNonNull(requestedTemplate);
        Objects.requireNonNull(calType);
        Objects.requireNonNull(locale);
        LocaleProviderAdapter lpa = LocaleProviderAdapter.getResourceBundleBased();
        return ((ResourceBundleBasedAdapter)lpa).getCandidateLocales("", locale).stream()
                .map(lpa::getLocaleResources)
                .map(lr -> lr.getLocalizedPattern(requestedTemplate, calType))
                .filter(Objects::nonNull)
                .findFirst()
                .or(() -> calType.equals("generic") ? Optional.empty():
                        Optional.of(getDateTimeFormatterPattern(requestedTemplate, "generic", locale)))
                .orElseThrow(() -> new DateTimeException("Requested template \"" + requestedTemplate +
                        "\" cannot be resolved in the locale \"" + locale + "\""));
    }

    @Override
    public Set<String> getAvailableLanguageTags() {
        return langtags;
    }
}
