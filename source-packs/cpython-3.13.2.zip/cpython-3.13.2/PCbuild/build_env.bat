@%comspec% /k env.bat %*
